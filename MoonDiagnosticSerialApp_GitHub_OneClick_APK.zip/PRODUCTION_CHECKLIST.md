
# Production checklist

- [ ] Firebase project created
- [ ] google-services.json added to app/
- [ ] Email/Password authentication enabled
- [ ] Admin user created
- [ ] users/{uid}.role = admin
- [ ] Firestore rules deployed
- [ ] Firestore indexes deployed
- [ ] Firebase App Check enabled
- [ ] Release signing key configured
- [ ] App versionCode/versionName updated
- [ ] Privacy policy / terms added if required
- [ ] Daily Firestore export/backup configured
