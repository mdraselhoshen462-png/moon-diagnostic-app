# 🌙 Moon Diagnostic Center — GitHub One-Click APK

এই version-এ GitHub Actions যোগ করা হয়েছে। Android Studio ছাড়াই GitHub-এর মাধ্যমে APK build করা যাবে।

## মোবাইল থেকে

1. GitHub account-এ লগইন করুন।
2. **New repository** তৈরি করুন, যেমন `moon-diagnostic-app`।
3. এই ZIP extract করে **সব ফাইল repository-এর root-এ upload** করুন।
4. `.github/workflows/build-apk.yml` ফাইলটি আছে কিনা নিশ্চিত করুন।
5. GitHub → **Actions** → **Build Moon Diagnostic APK** → **Run workflow** চাপুন।
6. Build শেষ হলে completed workflow খুলুন।
7. নিচে **Artifacts → Moon-Diagnostic-APK** থেকে APK download করুন।

## Firebase

Placeholder config-এর কারণে workflow build হতে পারবে, কিন্তু real Firebase login/database কাজ করবে না।

Real app-এর জন্য Firebase Console থেকে আপনার `google-services.json` নিয়ে repository-তে:

`app/google-services.json`

হিসেবে upload করুন। তারপর আবার Actions থেকে workflow চালান।

## গুরুত্বপূর্ণ

এটি Debug APK তৈরি করে। Play Store-এর জন্য signed Release APK/AAB workflow আলাদা করে configure করতে হবে।
