
package com.moondiagnostic.serial

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import java.text.SimpleDateFormat
import java.util.*

private val Blue=Color(0xFF0D47A1)
private val Green=Color(0xFF087F23)
private val Bg=Color(0xFFF5F8FC)

data class AppUser(val uid:String="",val name:String="",val email:String="",val role:String="user",val active:Boolean=true)
data class SerialItem(val id:String="",val dateKey:String="",val patientName:String="",val careOfName:String="",val doctorName:String="",val serialNo:Long=0,val status:String="অপেক্ষমাণ",val createdBy:String="",val createdAt:Long=0)
data class AuditItem(val id:String="",val action:String="",val actor:String="",val at:Long=0,val details:String="")

class MainActivity:ComponentActivity(){
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{MoonApp()}}
}

@Composable
fun MoonApp(){
    val auth=remember{FirebaseAuth.getInstance()}; val db=remember{FirebaseFirestore.getInstance()}
    var logged by remember{mutableStateOf(auth.currentUser!=null)}; var me by remember{mutableStateOf<AppUser?>(null)}
    if(!logged){Login{logged=true};return}
    LaunchedEffect(logged){auth.currentUser?.uid?.let{uid->db.collection("users").document(uid).addSnapshotListener{d,_->
        me=AppUser(uid,d?.getString("name")?:"",d?.getString("email")?:auth.currentUser?.email.orEmpty(),d?.getString("role")?:"user",d?.getBoolean("active")?:true)
    }}}
    if(me==null) Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){CircularProgressIndicator()}
    else if(!me!!.active) Column(Modifier.fillMaxSize(),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Text("এই অ্যাকাউন্টটি নিষ্ক্রিয় করা হয়েছে।");Button({auth.signOut();logged=false}){Text("লগইন পেজ")}}
    else MainShell(me!!,db){auth.signOut();logged=false;me=null}
}

@Composable
fun Login(ok:()->Unit){
    val auth=FirebaseAuth.getInstance();var email by remember{mutableStateOf("")};var pass by remember{mutableStateOf("")};var err by remember{mutableStateOf("")};var busy by remember{mutableStateOf(false)}
    Column(Modifier.fillMaxSize().background(Bg).padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){
        Text("🌙 MDC",fontSize=48.sp,fontWeight=FontWeight.Bold,color=Blue);Text("মুন ডায়াগনস্টিক সেন্টার",fontSize=24.sp,fontWeight=FontWeight.Bold);Text("সঠিক নির্ণয়, সুস্থ জীবনের প্রত্যয়",color=Blue)
        Spacer(Modifier.height(25.dp));Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(20.dp)){Column(Modifier.padding(20.dp)){
            Text("সিকিউর লগইন",fontSize=22.sp,fontWeight=FontWeight.Bold)
            OutlinedTextField(email,{email=it},Modifier.fillMaxWidth(),label={Text("ইমেইল")})
            Spacer(Modifier.height(8.dp));OutlinedTextField(pass,{pass=it},Modifier.fillMaxWidth(),label={Text("পাসওয়ার্ড")},singleLine=true)
            if(err.isNotBlank())Text(err,color=Color.Red,fontSize=12.sp)
            Spacer(Modifier.height(10.dp));Button({busy=true;auth.signInWithEmailAndPassword(email.trim(),pass).addOnSuccessListener{busy=false;ok()}.addOnFailureListener{busy=false;err=it.localizedMessage?:"লগইন ব্যর্থ"}},enabled=!busy,Modifier.fillMaxWidth()){Text(if(busy)"লগইন হচ্ছে..." else "লগইন")}
        }}
    }
}

@Composable
fun MainShell(me:AppUser,db:FirebaseFirestore,logout:()->Unit){
    var tab by remember{mutableIntStateOf(0)}
    var serials by remember{mutableStateOf(listOf<SerialItem>())};var doctors by remember{mutableStateOf(listOf<String>())};var care by remember{mutableStateOf(listOf<String>())}
    val today=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())
    LaunchedEffect(Unit){
        db.collection("serials").whereEqualTo("dateKey",today).orderBy("serialNo",Query.Direction.ASCENDING).addSnapshotListener{s,_->
            serials=s?.documents?.map{d->SerialItem(d.id,d.getString("dateKey")?:"",d.getString("patientName")?:"",d.getString("careOfName")?:"",d.getString("doctorName")?:"",d.getLong("serialNo")?:0,d.getString("status")?:"অপেক্ষমাণ",d.getString("createdBy")?:"",d.getLong("createdAt")?:0)}?:emptyList()
        }
        db.collection("doctors").orderBy("name").addSnapshotListener{s,_->{doctors=s?.documents?.mapNotNull{it.getString("name")}?:emptyList()}}
        db.collection("careOfs").orderBy("name").addSnapshotListener{s,_->{care=s?.documents?.mapNotNull{it.getString("name")}?:emptyList()}}
    }
    Scaffold(topBar={TopAppBar(title={Text("মুন ডায়াগনস্টিক সেন্টার",fontWeight=FontWeight.Bold)},actions={
        Text(me.role.uppercase(),fontSize=10.sp,color=Blue)
        IconButton(logout){Icon(Icons.Default.Logout,"লগআউট")}
    })},bottomBar={
        NavigationBar{
            val items=if(me.role=="admin") listOf(Triple(Icons.Default.List,"টোটাল সিরিয়াল",0),Triple(Icons.Default.AddCircle,"অ্যাড সিরিয়াল",1),Triple(Icons.Default.MedicalServices,"অ্যাড ডাক্তার",2),Triple(Icons.Default.Person,"অ্যাড কেয়ার অফ",3),Triple(Icons.Default.AdminPanelSettings,"অ্যাডমিন",4))
            else listOf(Triple(Icons.Default.List,"টোটাল সিরিয়াল",0),Triple(Icons.Default.AddCircle,"অ্যাড সিরিয়াল",1),Triple(Icons.Default.MedicalServices,"অ্যাড ডাক্তার",2),Triple(Icons.Default.Person,"অ্যাড কেয়ার অফ",3))
            items.forEach{(i,l,n)->NavigationBarItem(tab==n,{tab=n},{Icon(i,l)},{Text(l,fontSize=9.sp)})}
        }
    }){p->Column(Modifier.fillMaxSize().padding(p).background(Bg)){when(tab){
        0->Total(serials,me,db);1->AddSerial(serials,doctors,care,me,db);2->Names("ডাক্তার",doctors,me,db,"doctors");3->Names("কেয়ার অফ",care,me,db,"careOfs");4->AdminPanel(me,db,serials)
    }}}
}

@Composable
fun Total(serials:List<SerialItem>,me:AppUser,db:FirebaseFirestore){
    var q by remember{mutableStateOf("")};var f by remember{mutableStateOf("সব")}
    val shown=serials.filter{(f=="সব"||it.status==f)&&(q.isBlank()||it.patientName.contains(q,true)||it.doctorName.contains(q,true)||it.serialNo.toString()==q)}
    Column(Modifier.padding(16.dp)){Text("আজকের সিরিয়াল",fontSize=24.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){Stat("মোট",serials.size.toString(),Modifier.weight(1f));Stat("অপেক্ষমাণ",serials.count{it.status=="অপেক্ষমাণ"}.toString(),Modifier.weight(1f));Stat("সম্পন্ন",serials.count{it.status=="সম্পন্ন"}.toString(),Modifier.weight(1f))}
        Spacer(Modifier.height(8.dp));OutlinedTextField(q,{q=it},Modifier.fillMaxWidth(),label={Text("রোগী / ডাক্তার / সিরিয়াল খুঁজুন")},leadingIcon={Icon(Icons.Default.Search,null)})
        Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){listOf("সব","অপেক্ষমাণ","সম্পন্ন","বাতিল").forEach{FilterChip(f==it,{f=it},{Text(it)})}}
        LazyColumn(verticalArrangement=Arrangement.spacedBy(7.dp)){items(shown,key={it.id}){s->Card(Modifier.fillMaxWidth()){Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){
            Text("#${s.serialNo}",fontSize=22.sp,fontWeight=FontWeight.Bold,color=Blue);Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(s.patientName,fontWeight=FontWeight.Bold);Text("Care Of: ${s.careOfName}",fontSize=11.sp);Text(s.doctorName,fontSize=11.sp);Text(s.status,fontSize=11.sp)}
            if(me.role=="admin"||me.role=="operator"){IconButton({db.collection("serials").document(s.id).update("status","সম্পন্ন");audit(db,me,"SERIAL_COMPLETE","Serial #${s.serialNo}")}){Icon(Icons.Default.CheckCircle,"সম্পন্ন",tint=Green)};IconButton({db.collection("serials").document(s.id).update("status","বাতিল");audit(db,me,"SERIAL_CANCEL","Serial #${s.serialNo}")}){Icon(Icons.Default.Cancel,"বাতিল",tint=Color.Red)}}
        }}}}
    }
}
@Composable fun Stat(t:String,v:String,m:Modifier)=Card(m){Column(Modifier.padding(9.dp)){Text(t,fontSize=11.sp);Text(v,fontSize=23.sp,fontWeight=FontWeight.Bold,color=Blue)}}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddSerial(serials:List<SerialItem>,doctors:List<String>,care:List<String>,me:AppUser,db:FirebaseFirestore){
    var p by remember{mutableStateOf("")};var c by remember{mutableStateOf("")};var d by remember{mutableStateOf("")};var msg by remember{mutableStateOf("")};var busy by remember{mutableStateOf(false)}
    val date=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date());val next=(serials.maxOfOrNull{it.serialNo}?:0)+1
    Column(Modifier.padding(16.dp)){Text("অ্যাড সিরিয়াল",fontSize=24.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(9.dp))
        OutlinedTextField(p,{p=it},Modifier.fillMaxWidth(),label={Text("পেশেন্ট নেম *")});Spacer(Modifier.height(7.dp));OutlinedTextField(c,{c=it},Modifier.fillMaxWidth(),label={Text("কেয়ার অফ নেম")});Spacer(Modifier.height(7.dp))
        var exp by remember{mutableStateOf(false)}
        ExposedDropdownMenuBox(exp,{exp=!exp}){OutlinedTextField(d,{},Modifier.fillMaxWidth().menuAnchor(),label={Text("ডাক্তার নেম *")},readOnly=true,trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(exp)});ExposedDropdownMenu(exp,{exp=false}){doctors.forEach{DropdownMenuItem({Text(it)},{d=it;exp=false})}}}
        Spacer(Modifier.height(8.dp));Text("বর্তমান ধারাবাহিক নম্বর: #$next",color=Blue,fontWeight=FontWeight.Bold);if(msg.isNotBlank())Text(msg,color=Green)
        Spacer(Modifier.height(8.dp));Button({busy=true;val ref=db.collection("counters").document(date);db.runTransaction{tx->val s=tx.get(ref);val n=(s.getLong("lastSerial")?:0)+1;tx.set(ref,mapOf("lastSerial" to n),SetOptions.merge());n}.addOnSuccessListener{n->db.collection("serials").add(mapOf("dateKey" to date,"patientName" to p.trim(),"careOfName" to c.trim(),"doctorName" to d,"serialNo" to n,"status" to "অপেক্ষমাণ","createdBy" to me.uid,"createdAt" to System.currentTimeMillis())).addOnSuccessListener{audit(db,me,"SERIAL_CREATE","Serial #$n, $p");p="";c="";d="";msg="সিরিয়াল #$n যোগ হয়েছে";busy=false}.addOnFailureListener{busy=false;msg=it.localizedMessage?:"ব্যর্থ"}}.addOnFailureListener{busy=false;msg=it.localizedMessage?:"ব্যর্থ"}},enabled=!busy&&p.isNotBlank()&&d.isNotBlank(),Modifier.fillMaxWidth()){Text(if(busy)"সেভ হচ্ছে..." else "সিরিয়াল সেভ করুন")}
    }
}

@Composable fun Names(title:String,list:List<String>,me:AppUser,db:FirebaseFirestore,col:String){
    var n by remember{mutableStateOf("")};Column(Modifier.padding(16.dp)){Text("অ্যাড $title",fontSize=24.sp,fontWeight=FontWeight.Bold)
        if(me.role=="admin"){Row(verticalAlignment=Alignment.CenterVertically){OutlinedTextField(n,{n=it},Modifier.weight(1f),label={Text("$title-এর নাম")});IconButton({if(n.isNotBlank()){db.collection(col).add(mapOf("name" to n.trim(),"createdAt" to System.currentTimeMillis()));audit(db,me,"${title.uppercase()}_CREATE",n);n=""}}){Icon(Icons.Default.AddCircle,"যোগ")}}}else Text("Admin অনুমতি প্রয়োজন।",color=Color.Gray)
        LazyColumn(verticalArrangement=Arrangement.spacedBy(6.dp)){items(list){Card(Modifier.fillMaxWidth()){Row(Modifier.padding(12.dp)){Icon(if(title=="ডাক্তার")Icons.Default.MedicalServices else Icons.Default.Person,null,tint=Blue);Spacer(Modifier.width(8.dp));Text(it)}}}}
    }
}

@Composable
fun AdminPanel(me:AppUser,db:FirebaseFirestore,serials:List<SerialItem>){
    var page by remember{mutableIntStateOf(0)}
    val pages=listOf("ড্যাশবোর্ড","ইউজার","রিপোর্ট","সেটিংস","অডিট লগ")
    Column(Modifier.padding(14.dp)){Text("Admin Control Panel",fontSize=24.sp,fontWeight=FontWeight.Bold,color=Blue)
        Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){pages.forEachIndexed{i,t->FilterChip(page==i,{page=i},{Text(t,fontSize=11.sp)})}}
        Spacer(Modifier.height(8.dp));when(page){
            0->AdminDashboard(db);1->UserManager(db,me);2->Reports(db);3->SettingsPage(db,me);4->AuditLogs(db)
        }
    }
}

@Composable
fun AdminDashboard(db:FirebaseFirestore){
    var totalUsers by remember{mutableIntStateOf(0)};var totalDoctors by remember{mutableIntStateOf(0)};var totalCare by remember{mutableIntStateOf(0)};var totalSerials by remember{mutableIntStateOf(0)}
    LaunchedEffect(Unit){db.collection("users").get().addOnSuccessListener{totalUsers=it.size()};db.collection("doctors").get().addOnSuccessListener{totalDoctors=it.size()};db.collection("careOfs").get().addOnSuccessListener{totalCare=it.size()};db.collection("serials").get().addOnSuccessListener{totalSerials=it.size()}}
    Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Text("সিস্টেম ওভারভিউ",fontWeight=FontWeight.Bold)
        Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){Stat("Users",totalUsers.toString(),Modifier.weight(1f));Stat("Doctors",totalDoctors.toString(),Modifier.weight(1f))}
        Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){Stat("Care Of",totalCare.toString(),Modifier.weight(1f));Stat("All Serials",totalSerials.toString(),Modifier.weight(1f))}
        Text("Admin এখান থেকে user role, account active/inactive, reports, system settings এবং audit log নিয়ন্ত্রণ করতে পারবেন।",fontSize=13.sp,color=Color.Gray)
    }
}

@Composable
fun UserManager(db:FirebaseFirestore,me:AppUser){
    var users by remember{mutableStateOf(listOf<AppUser>())}
    LaunchedEffect(Unit){db.collection("users").addSnapshotListener{s,_->users=s?.documents?.map{d->AppUser(d.id,d.getString("name")?:"",d.getString("email")?:"",d.getString("role")?:"user",d.getBoolean("active")?:true)}?:emptyList()}}
    Column{Text("ব্যবহারকারী ও Role Management",fontWeight=FontWeight.Bold);Spacer(Modifier.height(6.dp))
        Text("নিরাপত্তার কারণে Firebase Authentication account create/delete Client App থেকে করা হয় না। Admin এখানে Firestore profile-এর role/active status নিয়ন্ত্রণ করেন।",fontSize=11.sp,color=Color.Gray)
        LazyColumn(verticalArrangement=Arrangement.spacedBy(6.dp)){items(users,key={it.uid}){u->UserRow(u,db,me)}}
    }
}
@Composable
fun UserRow(u:AppUser,db:FirebaseFirestore,me:AppUser){
    var role by remember(u.uid){mutableStateOf(u.role)};var active by remember(u.uid){mutableStateOf(u.active)}
    Card(Modifier.fillMaxWidth()){Column(Modifier.padding(10.dp)){Text(u.name.ifBlank{"Unnamed"},fontWeight=FontWeight.Bold);Text(u.email,fontSize=11.sp)
        Row(verticalAlignment=Alignment.CenterVertically){Text("Role:",fontSize=12.sp);Spacer(Modifier.width(5.dp));listOf("user","operator","admin").forEach{FilterChip(role==it,{role=it;db.collection("users").document(u.uid).update("role",it);audit(db,me,"ROLE_CHANGE","${u.email} -> $it")},{Text(it,fontSize=10.sp)})}
            Spacer(Modifier.width(5.dp));Switch(active,{active=it;db.collection("users").document(u.uid).update("active",it);audit(db,me,"USER_ACTIVE","${u.email} = $it")})
        }}
    }
}

@Composable
fun Reports(db:FirebaseFirestore){
    var date by remember{mutableStateOf(SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date()))};var rows by remember{mutableStateOf(listOf<SerialItem>())}
    Column{Text("দৈনিক রিপোর্ট",fontWeight=FontWeight.Bold);OutlinedTextField(date,{date=it},Modifier.fillMaxWidth(),label={Text("তারিখ YYYY-MM-DD")})
        Button({db.collection("serials").whereEqualTo("dateKey",date).orderBy("serialNo").get().addOnSuccessListener{s->rows=s.documents.map{d->SerialItem(d.id,date,d.getString("patientName")?:"",d.getString("careOfName")?:"",d.getString("doctorName")?:"",d.getLong("serialNo")?:0,d.getString("status")?:"",d.getString("createdBy")?:"",d.getLong("createdAt")?:0)}}},Modifier.fillMaxWidth()){Text("রিপোর্ট লোড করুন")}
        Text("মোট: ${rows.size} | সম্পন্ন: ${rows.count{it.status=="সম্পন্ন"}} | বাতিল: ${rows.count{it.status=="বাতিল"}}",fontWeight=FontWeight.Bold)
        LazyColumn{items(rows){Text("#${it.serialNo}  ${it.patientName} — ${it.doctorName} — ${it.status}",fontSize=12.sp,modifier=Modifier.padding(4.dp))}}
    }
}

@Composable
fun SettingsPage(db:FirebaseFirestore,me:AppUser){
    var centerName by remember{mutableStateOf("মুন ডায়াগনস্টিক সেন্টার")};var tagline by remember{mutableStateOf("সঠিক নির্ণয়, সুস্থ জীবনের প্রত্যয়")};var saved by remember{mutableStateOf(false)}
    LaunchedEffect(Unit){db.collection("settings").document("general").get().addOnSuccessListener{d->centerName=d.getString("centerName")?:centerName;tagline=d.getString("tagline")?:tagline}}
    Column{Text("সিস্টেম সেটিংস",fontWeight=FontWeight.Bold);OutlinedTextField(centerName,{centerName=it},Modifier.fillMaxWidth(),label={Text("সেন্টারের নাম")});OutlinedTextField(tagline,{tagline=it},Modifier.fillMaxWidth(),label={Text("Tagline")})
        Button({db.collection("settings").document("general").set(mapOf("centerName" to centerName,"tagline" to tagline),SetOptions.merge()).addOnSuccessListener{saved=true};audit(db,me,"SETTINGS_UPDATE","General settings")},Modifier.fillMaxWidth()){Text(if(saved)"সেভ হয়েছে" else "সেটিংস সেভ করুন")}
        Spacer(Modifier.height(8.dp));Text("নিরাপত্তা: Firebase App Check, backup এবং release signing production publish-এর আগে চালু করুন।",fontSize=12.sp,color=Color.Gray)
    }
}

@Composable
fun AuditLogs(db:FirebaseFirestore){
    var logs by remember{mutableStateOf(listOf<AuditItem>())}
    LaunchedEffect(Unit){db.collection("auditLogs").orderBy("at",Query.Direction.DESCENDING).limit(100).addSnapshotListener{s,_->logs=s?.documents?.map{d->AuditItem(d.id,d.getString("action")?:"",d.getString("actor")?:"",d.getLong("at")?:0,d.getString("details")?:"")}?:emptyList()}}
    LazyColumn(verticalArrangement=Arrangement.spacedBy(5.dp)){items(logs){l->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(9.dp)){Text(l.action,fontWeight=FontWeight.Bold);Text(l.details,fontSize=11.sp);Text(l.actor,fontSize=10.sp,color=Color.Gray);Text(SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.getDefault()).format(Date(l.at)),fontSize=10.sp,color=Color.Gray)}}}}
}

fun audit(db:FirebaseFirestore,me:AppUser,action:String,details:String){
    db.collection("auditLogs").add(mapOf("action" to action,"actor" to (me.email.ifBlank{me.uid}),"at" to System.currentTimeMillis(),"details" to details))
}
